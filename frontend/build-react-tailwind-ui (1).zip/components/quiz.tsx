"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, ChevronLeft, ChevronRight, FileText, Play, Trash2, BookOpenCheck } from "lucide-react"
import { cn } from "@/lib/utils"

interface QuizProps {
  subjectName?: string
  topicName?: string
  onBack?: () => void
}

const savedQuizzes = [
  { id: 1, topic: "Binary Trees", questions: 15, subject: "Data Structures", created: "2 hours ago", attempted: false },
  { id: 2, topic: "Sorting Algorithms", questions: 20, subject: "Algorithms", created: "1 day ago", attempted: true, score: 78 },
  { id: 3, topic: "Graph Traversal", questions: 12, subject: "Data Structures", created: "3 days ago", attempted: true, score: 65 },
  { id: 4, topic: "Dynamic Programming", questions: 18, subject: "Algorithms", created: "1 week ago", attempted: false },
]

const questions = [
  {
    id: 1,
    question: "Which of the following is TRUE for a Complete Binary Tree?",
    options: [
      { id: "a", text: "Every node has either 0 or 2 children." },
      { id: "b", text: "All levels are completely filled except possibly the last level, and the last level nodes are as far left as possible." },
      { id: "c", text: "All leaf nodes are at the same level." },
      { id: "d", text: "The tree must be a full binary tree." },
    ],
    correctAnswer: "b"
  },
]

export function Quiz({ subjectName, topicName, onBack }: QuizProps) {
  const [view, setView] = useState<"hub" | "quiz" | "result">(subjectName ? "quiz" : "hub")
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [timeRemaining] = useState("14:32")
  const [showEndModal, setShowEndModal] = useState(false)
  const [selectedQuiz, setSelectedQuiz] = useState<typeof savedQuizzes[0] | null>(null)

  const question = questions[currentQuestion]

  const handleSelectAnswer = (answerId: string) => {
    setSelectedAnswer(answerId)
    setAnswers({ ...answers, [currentQuestion]: answerId })
  }

  const handleStartQuiz = (quiz: typeof savedQuizzes[0]) => {
    setSelectedQuiz(quiz)
    setView("quiz")
  }

  const handleEndExam = () => {
    setShowEndModal(true)
  }

  const handleCloseResult = () => {
    setShowEndModal(false)
    setView("hub")
    if (onBack) onBack()
  }

  // Quiz Hub View
  if (view === "hub") {
    return (
      <div className="flex-1 p-6 space-y-6 overflow-auto">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Quiz Hub</h1>
            <p className="text-muted-foreground">Select a quiz to practice or review your progress</p>
          </div>
        </div>

        <div className="grid gap-4">
          {savedQuizzes.map((quiz) => (
            <Card key={quiz.id} className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{quiz.topic}</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                      <span>{quiz.subject}</span>
                      <span>•</span>
                      <span>{quiz.questions} questions</span>
                      <span>•</span>
                      <span>{quiz.created}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {quiz.attempted && (
                      <div className={cn(
                        "px-3 py-1 rounded-full text-sm font-medium",
                        quiz.score! >= 60 
                          ? "bg-green-500/20 text-green-400" 
                          : "bg-red-500/20 text-red-400"
                      )}>
                        Score: {quiz.score}%
                      </div>
                    )}
                    <Button 
                      onClick={() => handleStartQuiz(quiz)}
                      className="bg-primary hover:bg-primary/90"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      {quiz.attempted ? "Retry" : "Start"}
                    </Button>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  // Active Quiz View
  return (
    <div className="flex-1 flex h-screen overflow-hidden bg-background">
      {/* Main quiz area */}
      <div className="flex-1 flex flex-col">
        {/* Breadcrumb Header */}
        <div className="px-6 py-3 border-b border-border bg-card">
          <div className="text-sm text-muted-foreground">
            <span className="text-primary font-medium">{subjectName || selectedQuiz?.subject || "Data Structures"}</span>
            <span className="mx-2">{">"}</span>
            <span>Topic: {topicName || selectedQuiz?.topic || "Binary Trees"}</span>
            <span className="mx-2">{">"}</span>
            <span>15 Questions</span>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div className="flex items-center gap-4">
            <span className="text-foreground font-medium">
              Question {currentQuestion + 1} of 15
            </span>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>{timeRemaining}</span>
            </div>
            <Button variant="destructive" size="sm" onClick={handleEndExam}>
              End Exam
            </Button>
          </div>
        </div>

        {/* Question content */}
        <div className="flex-1 flex items-center justify-center p-8">
          <Card className="max-w-2xl w-full bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-medium text-foreground leading-relaxed">
                {question.question}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {question.options.map((option) => (
                <button
                  key={option.id}
                  onClick={() => handleSelectAnswer(option.id)}
                  className={cn(
                    "w-full flex items-start gap-4 p-4 rounded-xl border transition-colors text-left",
                    selectedAnswer === option.id
                      ? "border-primary bg-primary/10"
                      : "border-border bg-secondary/30 hover:bg-secondary"
                  )}
                >
                  <span className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0",
                    selectedAnswer === option.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-muted-foreground"
                  )}>
                    {option.id.toUpperCase()}
                  </span>
                  <span className="text-foreground pt-1">{option.text}</span>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Footer navigation */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-border">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
            disabled={currentQuestion === 0}
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          <Button
            onClick={() => setCurrentQuestion(Math.min(14, currentQuestion + 1))}
            className="bg-primary hover:bg-primary/90"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>

      {/* Answer grid sidebar */}
      <div className="w-64 bg-card border-l border-border p-4">
        <h3 className="font-semibold text-foreground mb-4">Answer Grid</h3>
        <div className="grid grid-cols-5 gap-2">
          {Array.from({ length: 15 }, (_, i) => (
            <button
              key={i}
              onClick={() => setCurrentQuestion(i)}
              className={cn(
                "w-10 h-10 rounded-lg flex items-center justify-center text-sm font-medium transition-colors",
                currentQuestion === i
                  ? "bg-primary text-primary-foreground"
                  : answers[i]
                  ? "bg-green-500/20 text-green-400 border border-green-500/30"
                  : "bg-secondary text-muted-foreground hover:bg-secondary/80"
              )}
            >
              {i + 1}
            </button>
          ))}
        </div>

        <div className="mt-8 space-y-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Answered</span>
            <span className="text-foreground font-medium">{Object.keys(answers).length}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Current</span>
            <span className="text-primary font-medium">{currentQuestion + 1}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Unanswered</span>
            <span className="text-foreground font-medium">{15 - Object.keys(answers).length}</span>
          </div>
        </div>
      </div>

      {/* Post-Quiz Result Modal */}
      {showEndModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md bg-card border-border">
            <CardHeader className="text-center">
              <CardTitle className="text-xl font-bold text-foreground">
                Quiz Complete!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-5xl font-bold text-orange-400 mb-2">55%</div>
                <p className="text-muted-foreground">You answered 8 out of 15 questions correctly</p>
              </div>

              <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4">
                <p className="text-sm text-orange-400 leading-relaxed">
                  <strong>{`"Binary Trees"`}</strong> has been flagged as a <strong>Knowledge Gap</strong> (&lt;60%) 
                  and will be prioritized in future sessions.
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <Button 
                  className="w-full bg-primary hover:bg-primary/90"
                  onClick={() => {/* Review answers with AI explanations */}}
                >
                  <BookOpenCheck className="w-4 h-4 mr-2" />
                  Review Answers
                </Button>
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={handleCloseResult}
                  >
                    Back to Hub
                  </Button>
                  <Button 
                    variant="outline"
                    className="flex-1 border-primary/40 text-primary hover:bg-primary/10"
                    onClick={() => {
                      setShowEndModal(false)
                      setCurrentQuestion(0)
                      setAnswers({})
                      setSelectedAnswer(null)
                    }}
                  >
                    Retry Quiz
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
