"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  FolderOpen, 
  FileText, 
  Search, 
  Plus,
  ChevronRight,
  BookOpen,
  Clock,
  HardDrive
} from "lucide-react"
import { cn } from "@/lib/utils"

interface SubjectsProps {
  onOpenStudy: (subject: string, document: string) => void
}

const subjects = [
  { 
    id: "data-structures",
    name: "Data Structures", 
    documentCount: 8, 
    lastStudied: "2 hours ago",
    progress: 68,
    storageUsed: 42,
    documents: [
      { name: "Binary Trees.pdf", pages: 45, fileSize: "4.2 MB" },
      { name: "Linked Lists.pdf", pages: 28, fileSize: "2.8 MB" },
      { name: "Hash Tables.pdf", pages: 32, fileSize: "3.1 MB" },
      { name: "Graphs.pdf", pages: 56, fileSize: "5.6 MB" },
    ]
  },
  { 
    id: "algorithms",
    name: "Algorithms", 
    documentCount: 6, 
    lastStudied: "1 day ago",
    progress: 55,
    storageUsed: 31,
    documents: [
      { name: "Sorting Algorithms.pdf", pages: 38, fileSize: "3.8 MB" },
      { name: "Dynamic Programming.pdf", pages: 52, fileSize: "5.2 MB" },
      { name: "Greedy Algorithms.pdf", pages: 24, fileSize: "2.4 MB" },
    ]
  },
  { 
    id: "operating-systems",
    name: "Operating Systems", 
    documentCount: 5, 
    lastStudied: "3 days ago",
    progress: 42,
    storageUsed: 18,
    documents: [
      { name: "Process Management.pdf", pages: 42, fileSize: "4.5 MB" },
      { name: "Memory Management.pdf", pages: 38, fileSize: "3.9 MB" },
    ]
  },
  { 
    id: "computer-networks",
    name: "Computer Networks", 
    documentCount: 4, 
    lastStudied: "5 days ago",
    progress: 38,
    storageUsed: 12,
    documents: [
      { name: "TCP IP Protocol.pdf", pages: 48, fileSize: "4.8 MB" },
      { name: "Network Security.pdf", pages: 35, fileSize: "3.5 MB" },
    ]
  },
  { 
    id: "database-systems",
    name: "Database Systems", 
    documentCount: 7, 
    lastStudied: "1 week ago",
    progress: 72,
    storageUsed: 56,
    documents: [
      { name: "SQL Fundamentals.pdf", pages: 32, fileSize: "3.2 MB" },
      { name: "Normalization.pdf", pages: 28, fileSize: "2.8 MB" },
      { name: "Transactions.pdf", pages: 24, fileSize: "2.4 MB" },
    ]
  },
]

export function Subjects({ onOpenStudy }: SubjectsProps) {
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")

  const currentSubject = subjects.find(s => s.id === selectedSubject)

  const filteredSubjects = subjects.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  if (selectedSubject && currentSubject) {
    return (
      <div className="flex-1 p-6 space-y-6 overflow-auto">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm">
          <button 
            onClick={() => setSelectedSubject(null)}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            Subjects
          </button>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
          <span className="text-foreground font-medium">{currentSubject.name}</span>
        </div>

        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{currentSubject.name}</h1>
            <p className="text-muted-foreground">{currentSubject.documentCount} documents</p>
          </div>
          <Button className="bg-primary hover:bg-primary/90">
            <Plus className="w-4 h-4 mr-2" />
            Add Document
          </Button>
        </div>

        {/* Upload Drop Zone */}
        <div className="border-2 border-dashed border-border rounded-xl p-8 text-center bg-secondary/20 hover:bg-secondary/30 transition-colors cursor-pointer">
          <div className="flex flex-col items-center gap-2">
            <FileText className="w-10 h-10 text-muted-foreground" />
            <p className="text-foreground font-medium">Drop PDF files here or click to upload</p>
            <p className="text-sm text-muted-foreground">Max File Size: <span className="font-bold text-yellow-500">10MB</span></p>
          </div>
        </div>

        {/* Documents List */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-foreground">Documents</h2>
          {currentSubject.documents.map((doc, idx) => (
            <Card 
              key={idx} 
              className="bg-card border-border hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => onOpenStudy(currentSubject.name, doc.name)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-foreground">{doc.name}</div>
                    <div className="text-sm text-muted-foreground">{doc.pages} pages</div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-sm text-muted-foreground">
                      File Size: <span className="text-foreground">{doc.fileSize}</span>
                    </div>
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/30">
                      <span className="w-2 h-2 rounded-full bg-green-500" />
                      <span className="text-xs font-medium text-green-400">Status: Vectorized</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 p-6 space-y-6 overflow-auto">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Subjects</h1>
          <p className="text-muted-foreground">Organize your study materials by subject</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          New Subject
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search subjects..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-secondary border-border"
        />
      </div>

      {/* Subject Folders Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSubjects.map((subject) => (
          <Card 
            key={subject.id}
            onClick={() => setSelectedSubject(subject.id)}
            className="bg-card border-border hover:border-primary/50 transition-all cursor-pointer group"
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/30 transition-colors">
                  <FolderOpen className="w-7 h-7 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground truncate">{subject.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                    <BookOpen className="w-4 h-4" />
                    <span>{subject.documentCount} documents</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                    <Clock className="w-4 h-4" />
                    <span>{subject.lastStudied}</span>
                  </div>
                </div>
              </div>
              
              {/* Progress bar */}
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-muted-foreground">Mastery</span>
                  <span className="text-foreground font-medium">{subject.progress}%</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all",
                      subject.progress >= 70 ? "bg-green-500" : subject.progress >= 40 ? "bg-yellow-500" : "bg-orange-500"
                    )}
                    style={{ width: `${subject.progress}%` }}
                  />
                </div>
              </div>

              {/* Storage usage indicator */}
              <div className="mt-3">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <HardDrive className="w-3 h-3" />
                    Storage
                  </span>
                  <span className="text-muted-foreground">{subject.storageUsed}MB / 100MB</span>
                </div>
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all",
                      subject.storageUsed >= 80 ? "bg-red-500" : "bg-primary"
                    )}
                    style={{ width: `${subject.storageUsed}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
