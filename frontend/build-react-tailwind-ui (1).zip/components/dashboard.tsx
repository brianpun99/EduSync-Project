"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Target, FileText, AlertTriangle, Clock, ChevronRight, TrendingUp, TrendingDown } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export function Dashboard() {
  return (
    <div className="flex-1 p-6 space-y-6 overflow-auto">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search topics, documents, concepts..." 
              className="pl-10 bg-secondary border-border"
            />
          </div>
        </div>
      </div>

      {/* Greeting */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Good evening, Aiman</h1>
          <p className="text-muted-foreground">Keep learning, keep growing!</p>
        </div>
        <div className="bg-secondary/50 rounded-xl p-4 border border-border">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Target className="w-4 h-4" />
            <span>{"Today's Goal"}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-foreground">3</span>
            <span className="text-muted-foreground">/ 5 Topics</span>
            <span className="text-xs px-2 py-0.5 bg-green-500/20 text-green-400 rounded-full flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              8%
            </span>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          label="Overall Mastery"
          value="68%"
          subtext="You're doing great!"
          trend="up"
          trendValue="+3 this week"
          color="primary"
          showProgress
          progress={68}
        />
        <StatCard 
          label="Documents"
          value="24"
          subtext="Documents loaded"
          color="cyan"
        />
        <StatCard 
          label="Weak Topics"
          value="7"
          subtext="Need more revision"
          trend="down"
          color="orange"
        />
        <StatCard 
          label="Study Time"
          value="4h 32m"
          subtext="Today"
          trend="up"
          trendValue="+12% from yesterday"
          color="green"
        />
      </div>

      {/* Main content grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Weak Topics */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold text-foreground">Top Weak Topics</CardTitle>
            <Button variant="ghost" size="sm" className="text-muted-foreground text-xs">
              View all <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <TopicProgress name="Binary Trees" progress={32} color="bg-red-500" />
            <TopicProgress name="Heap Operations" progress={38} color="bg-red-500" />
            <TopicProgress name="Dynamic Programming" progress={41} color="bg-red-500" />
            <TopicProgress name="Graph Traversal" progress={45} color="bg-orange-500" />
            <TopicProgress name="Hash Tables" progress={52} color="bg-orange-500" />
            <TopicProgress name="Recursion" progress={55} color="bg-orange-500" />
            <TopicProgress name="Backtracking" progress={58} color="bg-orange-500" />
          </CardContent>
        </Card>

        {/* Recent Activity - replaces AI Insights */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold text-foreground">Recent Activity</CardTitle>
            <Button variant="ghost" size="sm" className="text-muted-foreground text-xs">
              View full timeline
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <ActivityItem 
                icon={<FileText className="w-4 h-4" />}
                title="Studied Binary Trees"
                time="2h ago"
                color="bg-primary/20 text-primary"
              />
              <ActivityItem 
                icon={<AlertTriangle className="w-4 h-4" />}
                title="Quiz: Sorting Algorithms"
                time="5h ago"
                subtitle="Score: 78%"
                color="bg-orange-500/20 text-orange-400"
              />
              <ActivityItem 
                icon={<FileText className="w-4 h-4" />}
                title="Chat: DP Memoization"
                time="1d ago"
                color="bg-cyan-500/20 text-cyan-400"
              />
              <ActivityItem 
                icon={<FileText className="w-4 h-4" />}
                title="Document: OS_Notes.pdf"
                time="2d ago"
                color="bg-green-500/20 text-green-400"
              />
              <ActivityItem 
                icon={<Clock className="w-4 h-4" />}
                title="Completed: Graph Theory Review"
                time="3d ago"
                color="bg-purple-500/20 text-purple-400"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function StatCard({ 
  label, 
  value, 
  subtext, 
  trend, 
  trendValue,
  color,
  showProgress,
  progress 
}: { 
  label: string
  value: string
  subtext: string
  trend?: "up" | "down"
  trendValue?: string
  color: string
  showProgress?: boolean
  progress?: number
}) {
  const colorClasses: Record<string, string> = {
    primary: "text-primary",
    cyan: "text-cyan-400",
    orange: "text-orange-400",
    green: "text-green-400"
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="text-sm text-muted-foreground mb-1">{label}</div>
        <div className={`text-2xl lg:text-3xl font-bold ${colorClasses[color]}`}>{value}</div>
        {showProgress && progress && (
          <Progress value={progress} className="h-1.5 mt-2 bg-secondary" />
        )}
        <div className="text-xs text-muted-foreground mt-1">{subtext}</div>
        {trendValue && (
          <div className="flex items-center gap-1 mt-1">
            {trend === "up" ? (
              <TrendingUp className="w-3 h-3 text-green-400" />
            ) : (
              <TrendingDown className="w-3 h-3 text-red-400" />
            )}
            <span className={`text-xs ${trend === "up" ? "text-green-400" : "text-red-400"}`}>
              {trendValue}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function TopicProgress({ name, progress, color }: { name: string; progress: number; color: string }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-sm">
        <span className="text-foreground">{name}</span>
        <span className="text-muted-foreground">{progress}%</span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all`} style={{ width: `${progress}%` }} />
      </div>
    </div>
  )
}

function ActivityItem({ 
  icon, 
  title, 
  time, 
  subtitle,
  color 
}: { 
  icon: React.ReactNode
  title: string
  time: string
  subtitle?: string
  color: string
}) {
  return (
    <div className="flex items-center gap-3">
      <div className={`w-8 h-8 rounded-lg ${color} flex items-center justify-center`}>
        {icon}
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium text-foreground">{title}</div>
        {subtitle && <div className="text-xs text-muted-foreground">{subtitle}</div>}
      </div>
      <div className="text-xs text-muted-foreground">{time}</div>
    </div>
  )
}
