"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  User,
  Lock,
  Eye,
  EyeOff,
  Shield,
  Calendar,
  Mail,
  KeyRound,
  HelpCircle,
  Info,
  ChevronDown,
  Cpu,
  Database,
  HardDrive,
  LogOut
} from "lucide-react"
import { cn } from "@/lib/utils"

type SettingsTab = "account" | "security" | "help" | "about"

const settingsNav = [
  { id: "account" as SettingsTab, icon: User, label: "Account Information" },
  { id: "security" as SettingsTab, icon: Shield, label: "Privacy & Security" },
  { id: "help" as SettingsTab, icon: HelpCircle, label: "Help & Support (FAQ)" },
  { id: "about" as SettingsTab, icon: Info, label: "About EduSync" },
]

export function Settings({ onLogout }: { onLogout?: () => void }) {
  const [activeTab, setActiveTab] = useState<SettingsTab>("account")

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Manage your account and security preferences</p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Secondary vertical navigation */}
          <nav className="lg:w-64 flex-shrink-0 space-y-1">
            {settingsNav.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-left",
                  activeTab === item.id
                    ? "bg-primary/20 text-primary"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Tab content */}
          <div className="flex-1 min-w-0">
            {activeTab === "account" && <AccountTab onLogout={onLogout} />}
            {activeTab === "security" && <SecurityTab />}
            {activeTab === "help" && <HelpTab />}
            {activeTab === "about" && <AboutTab />}
          </div>
        </div>
      </div>
    </div>
  )
}

function AccountTab({ onLogout }: { onLogout?: () => void }) {
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground flex items-center gap-2">
          <User className="w-5 h-5 text-primary" />
          Account Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4">
          <div className="flex items-center justify-between py-3 border-b border-border">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="text-sm font-medium text-foreground">Email</div>
                <div className="text-sm text-muted-foreground">aiman@example.com</div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between py-3 border-b border-border">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="text-sm font-medium text-foreground">Username</div>
                <div className="text-sm text-muted-foreground">aiman_dev</div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between py-3 border-b border-border">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="text-sm font-medium text-foreground">Account Created</div>
                <div className="text-sm text-muted-foreground">January 15, 2024</div>
              </div>
            </div>
          </div>
        </div>

        {/* Log Out */}
        <div className="pt-2">
          {!showLogoutConfirm ? (
            <Button
              variant="outline"
              onClick={() => setShowLogoutConfirm(true)}
              className="w-full border-red-500/40 text-red-400 hover:bg-red-500/10 hover:text-red-400"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Log Out
            </Button>
          ) : (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 space-y-3">
              <p className="text-sm text-foreground">
                Are you sure you want to log out? You will need your password to sign back in.
              </p>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowLogoutConfirm(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-red-500 hover:bg-red-600 text-white"
                  onClick={onLogout}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Confirm Log Out
                </Button>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function SecurityTab() {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showRecoveryKey, setShowRecoveryKey] = useState(false)
  const [revealPassword, setRevealPassword] = useState("")
  const [isKeyRevealed, setIsKeyRevealed] = useState(false)

  const recoveryKey = "EDUSYNC-X7B9-M2Q4-P9L1"

  const handleRevealKey = () => {
    if (revealPassword.length > 0) {
      setIsKeyRevealed(true)
    }
  }

  return (
    <div className="space-y-6">
      {/* Change Password */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Lock className="w-5 h-5 text-primary" />
            Change Password
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Current Password</label>
            <div className="relative">
              <Input
                type={showCurrentPassword ? "text" : "password"}
                placeholder="Enter current password"
                className="bg-secondary border-border pr-10"
              />
              <button
                type="button"
                onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">New Password</label>
            <div className="relative">
              <Input
                type={showNewPassword ? "text" : "password"}
                placeholder="Enter new password"
                className="bg-secondary border-border pr-10"
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Confirm New Password</label>
            <Input
              type="password"
              placeholder="Confirm new password"
              className="bg-secondary border-border"
            />
          </div>

          <Button className="bg-primary hover:bg-primary/90">
            Update Password
          </Button>
        </CardContent>
      </Card>

      {/* Master Recovery Key */}
      <Card className="bg-card border-border border-yellow-500/30">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-yellow-500" />
            Master Recovery Key
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            This is the only way to recover your account if you forget your password.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isKeyRevealed ? (
            <>
              <div className="bg-secondary/50 border border-border rounded-xl p-6 text-center relative overflow-hidden">
                <div className="blur-lg select-none">
                  <code className="text-2xl font-mono font-bold text-primary tracking-wider">
                    {recoveryKey}
                  </code>
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Shield className="w-8 h-8 text-muted-foreground" />
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium text-foreground">Enter Password to Reveal Key</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type={showRecoveryKey ? "text" : "password"}
                      placeholder="Enter your password"
                      value={revealPassword}
                      onChange={(e) => setRevealPassword(e.target.value)}
                      className="bg-secondary border-border pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRecoveryKey(!showRecoveryKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showRecoveryKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <Button 
                    onClick={handleRevealKey}
                    variant="outline" 
                    className="border-yellow-500/50 text-yellow-500 hover:bg-yellow-500/20"
                  >
                    Reveal Key
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-6 text-center">
                <code className="text-2xl font-mono font-bold text-yellow-500 tracking-wider">
                  {recoveryKey}
                </code>
              </div>

              <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                <p className="text-sm text-red-400">
                  <strong>Warning:</strong> Do not share this key with anyone. Store it securely offline. 
                  This is the only way to recover your account.
                </p>
              </div>

              <Button 
                onClick={() => {
                  setIsKeyRevealed(false)
                  setRevealPassword("")
                }}
                variant="outline" 
                className="w-full"
              >
                Hide Key
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

const faqs = [
  {
    q: "How does EduSync work offline?",
    a: "EduSync processes your documents locally and stores them in an on-device vector database. Once your materials are loaded, the core study features work without an internet connection.",
  },
  {
    q: "Why can't I reset my password via email?",
    a: "EduSync is privacy-first and offline-first. We never store your email on a server for recovery. Instead, you use your Master Recovery Key, which only you hold.",
  },
  {
    q: "What is the maximum file size I can upload?",
    a: "Each document must be 10MB or smaller. This keeps local processing fast and storage usage manageable across your subjects.",
  },
  {
    q: "How are knowledge gaps detected?",
    a: "Any quiz topic scoring below 60% is flagged as a Knowledge Gap and prioritized in your adaptive learning path and future quiz sessions.",
  },
]

function HelpTab() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-primary" />
          Help & Support (FAQ)
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Answers available offline. No internet connection required.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {faqs.map((faq, idx) => (
          <div key={idx} className="border border-border rounded-xl overflow-hidden">
            <button
              onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
              className="w-full flex items-center justify-between gap-3 p-4 text-left hover:bg-secondary/40 transition-colors"
            >
              <span className="text-sm font-medium text-foreground">{faq.q}</span>
              <ChevronDown 
                className={cn(
                  "w-4 h-4 text-muted-foreground flex-shrink-0 transition-transform",
                  openIndex === idx && "rotate-180"
                )}
              />
            </button>
            {openIndex === idx && (
              <div className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">
                {faq.a}
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function AboutTab() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Info className="w-5 h-5 text-primary" />
          About EduSync
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4 pb-4 border-b border-border">
          <div className="w-14 h-14 rounded-xl bg-primary/20 flex items-center justify-center">
            <Info className="w-7 h-7 text-primary" />
          </div>
          <div>
            <div className="font-semibold text-foreground">EduSync</div>
            <div className="text-sm text-muted-foreground">Adaptive offline-first AI study assistant</div>
          </div>
        </div>

        <InfoRow icon={<Info className="w-5 h-5 text-muted-foreground" />} label="App Version" value="1.0.0" />
        <InfoRow icon={<Cpu className="w-5 h-5 text-muted-foreground" />} label="Inference Engine" value="Ollama (Local) — llama3:8b" />
        <InfoRow icon={<Database className="w-5 h-5 text-muted-foreground" />} label="Vector Database" value="ChromaDB (Local)" />
        <InfoRow icon={<HardDrive className="w-5 h-5 text-muted-foreground" />} label="Storage Used" value="159 MB / 500 MB" />
        <InfoRow icon={<Shield className="w-5 h-5 text-muted-foreground" />} label="System Status" value="All systems operational" valueClass="text-green-400" />
      </CardContent>
    </Card>
  )
}

function InfoRow({ 
  icon, 
  label, 
  value,
  valueClass
}: { 
  icon: React.ReactNode
  label: string
  value: string
  valueClass?: string
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-3">
        {icon}
        <span className="text-sm font-medium text-foreground">{label}</span>
      </div>
      <span className={cn("text-sm text-muted-foreground", valueClass)}>{value}</span>
    </div>
  )
}
