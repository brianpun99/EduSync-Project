"use client"

import { useState } from "react"
import { LandingPage } from "@/components/landing-page"
import { Auth } from "@/components/auth"
import { Sidebar } from "@/components/sidebar"
import { Dashboard } from "@/components/dashboard"
import { Subjects } from "@/components/subjects"
import { StudyWorkspace } from "@/components/study-workspace"
import { QuizHistory } from "@/components/quiz-history"
import { Analytics } from "@/components/analytics"
import { Settings } from "@/components/settings"
import { Quiz } from "@/components/quiz"

type View = "dashboard" | "subjects" | "quizzes" | "analytics" | "settings" | "quiz" | "study"
type AppStage = "landing" | "auth" | "app"

interface StudyContext {
  subject: string
  document: string
}

export default function Home() {
  const [stage, setStage] = useState<AppStage>("landing")
  const [activeView, setActiveView] = useState<View>("dashboard")
  const [studyContext, setStudyContext] = useState<StudyContext | null>(null)
  const [quizContext, setQuizContext] = useState<{ subject: string; topic: string } | null>(null)

  // Handle opening a document from Subjects
  const handleOpenStudy = (subject: string, document: string) => {
    setStudyContext({ subject, document })
    setActiveView("study")
  }

  // Handle going back from Study Workspace
  const handleBackFromStudy = () => {
    setStudyContext(null)
    setActiveView("subjects")
  }

  // Handle generating quiz from Study Workspace
  const handleGenerateQuiz = () => {
    if (studyContext) {
      setQuizContext({
        subject: studyContext.subject,
        topic: studyContext.document.replace(".pdf", "")
      })
      setActiveView("quiz")
    }
  }

  // Handle logging out — clears session context and returns to landing
  const handleLogout = () => {
    setStudyContext(null)
    setQuizContext(null)
    setActiveView("dashboard")
    setStage("landing")
  }

  // Handle going back from Quiz
  const handleBackFromQuiz = () => {
    setQuizContext(null)
    if (studyContext) {
      setActiveView("study")
    } else {
      setActiveView("quizzes")
    }
  }

  // Show landing page first
  if (stage === "landing") {
    return <LandingPage onGetStarted={() => setStage("auth")} />
  }

  // Show authentication screen
  if (stage === "auth") {
    return <Auth onAuthenticated={() => setStage("app")} />
  }

  // Study Workspace is full-screen without sidebar
  if (activeView === "study" && studyContext) {
    return (
      <StudyWorkspace
        subjectName={studyContext.subject}
        documentName={studyContext.document}
        onBack={handleBackFromStudy}
        onGenerateQuiz={handleGenerateQuiz}
      />
    )
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar activeView={activeView} onViewChange={setActiveView} />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {activeView === "dashboard" && <Dashboard />}
        {activeView === "subjects" && <Subjects onOpenStudy={handleOpenStudy} />}
        {activeView === "quizzes" && <QuizHistory />}
        {activeView === "analytics" && <Analytics />}
        {activeView === "settings" && <Settings onLogout={handleLogout} />}
        {activeView === "quiz" && (
          <Quiz 
            subjectName={quizContext?.subject}
            topicName={quizContext?.topic}
            onBack={handleBackFromQuiz}
          />
        )}
      </main>
    </div>
  )
}
