"use client"

import { cn } from "@/lib/utils"
import { 
  LayoutDashboard, 
  FolderOpen, 
  BarChart3, 
  Settings,
  ClipboardList,
  Brain
} from "lucide-react"

type View = "dashboard" | "subjects" | "quizzes" | "analytics" | "settings" | "quiz" | "study"

interface SidebarProps {
  activeView: View
  onViewChange: (view: View) => void
}

const navItems = [
  { id: "dashboard" as View, icon: LayoutDashboard, label: "Dashboard" },
  { id: "subjects" as View, icon: FolderOpen, label: "Subjects" },
  { id: "quizzes" as View, icon: ClipboardList, label: "Quizzes" },
  { id: "analytics" as View, icon: BarChart3, label: "Analytics" },
  { id: "settings" as View, icon: Settings, label: "Settings" },
]

export function Sidebar({ activeView, onViewChange }: SidebarProps) {
  return (
    <aside className="w-16 lg:w-64 bg-card border-r border-border flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <Brain className="w-6 h-6 text-primary" />
          </div>
          <span className="text-lg font-semibold text-foreground hidden lg:block">EduSync</span>
        </div>
      </div>

      {/* Main navigation */}
      <nav className="flex-1 p-2 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
              activeView === item.id || (activeView === "study" && item.id === "subjects") || (activeView === "quiz" && item.id === "quizzes")
                ? "bg-primary/20 text-primary"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            )}
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            <span className="hidden lg:block text-sm font-medium">{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  )
}
