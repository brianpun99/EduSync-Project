"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Brain, Eye, EyeOff, Copy, Check, AlertTriangle } from "lucide-react"
import { cn } from "@/lib/utils"

interface AuthProps {
  onAuthenticated: () => void
}

export function Auth({ onAuthenticated }: AuthProps) {
  const [mode, setMode] = useState<"login" | "register">("login")
  const [showPassword, setShowPassword] = useState(false)
  const [showRecoveryModal, setShowRecoveryModal] = useState(false)
  const [keySaved, setKeySaved] = useState(false)
  const [copied, setCopied] = useState(false)
  
  const [email, setEmail] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const recoveryKey = "EDUSYNC-X7B9-M2Q4-P9L1"

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault()
    setShowRecoveryModal(true)
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    onAuthenticated()
  }

  const handleCopyKey = () => {
    navigator.clipboard.writeText(recoveryKey)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleConfirmKey = () => {
    if (keySaved) {
      setShowRecoveryModal(false)
      onAuthenticated()
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-card border-border">
        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
              <Brain className="w-10 h-10 text-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-foreground">
            {mode === "login" ? "Welcome Back" : "Create Account"}
          </CardTitle>
          <p className="text-sm text-muted-foreground mt-1">
            {mode === "login" 
              ? "Sign in to continue your learning journey" 
              : "Start your offline-first learning experience"
            }
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={mode === "login" ? handleLogin : handleRegister} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Email</label>
              <Input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-secondary border-border"
                required
              />
            </div>

            {mode === "register" && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Username</label>
                <Input
                  type="text"
                  placeholder="Your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-secondary border-border"
                  required
                />
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Password</label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-secondary border-border pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
              {mode === "login" ? "Sign In" : "Create Account"}
            </Button>
          </form>

          {mode === "login" && (
            <button
              onClick={() => {/* Handle offline recovery */}}
              className="w-full mt-3 text-sm text-primary hover:underline"
            >
              Use Offline Recovery Key
            </button>
          )}

          <div className="mt-6 text-center">
            <span className="text-sm text-muted-foreground">
              {mode === "login" ? "Don't have an account? " : "Already have an account? "}
            </span>
            <button
              onClick={() => setMode(mode === "login" ? "register" : "login")}
              className="text-sm text-primary hover:underline"
            >
              {mode === "login" ? "Sign up" : "Sign in"}
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Recovery Key Modal */}
      {showRecoveryModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-lg bg-card border-border">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-yellow-500" />
                </div>
              </div>
              <CardTitle className="text-xl font-bold text-foreground">
                Master Recovery Key
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-2">
                Save this key to recover your account
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-secondary/50 border border-border rounded-xl p-6 text-center">
                <code className="text-2xl font-mono font-bold text-primary tracking-wider">
                  {recoveryKey}
                </code>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopyKey}
                  className="mt-4 text-muted-foreground hover:text-foreground"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-2 text-green-500" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Key
                    </>
                  )}
                </Button>
              </div>

              <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                <p className="text-sm text-red-400 leading-relaxed">
                  <strong>EduSync is an offline-first system.</strong> Write this key down physically. 
                  We cannot send password reset emails.
                </p>
              </div>

              <label className="flex items-start gap-3 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={keySaved}
                  onChange={(e) => setKeySaved(e.target.checked)}
                  className="w-5 h-5 rounded border-border bg-secondary mt-0.5 accent-primary"
                />
                <span className="text-sm text-foreground group-hover:text-primary transition-colors">
                  I have securely saved this key.
                </span>
              </label>

              <Button
                onClick={handleConfirmKey}
                disabled={!keySaved}
                className={cn(
                  "w-full",
                  keySaved 
                    ? "bg-primary hover:bg-primary/90" 
                    : "bg-secondary text-muted-foreground cursor-not-allowed"
                )}
              >
                Continue to EduSync
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
