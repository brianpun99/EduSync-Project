"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  ChevronLeft,
  ChevronRight,
  Send,
  FileText,
  Bot,
  User,
  Sparkles,
  Upload,
  ZoomIn,
  ZoomOut,
  Maximize2
} from "lucide-react"
import { cn } from "@/lib/utils"

interface StudyWorkspaceProps {
  subjectName: string
  documentName: string
  onBack: () => void
  onGenerateQuiz: () => void
}

const chatMessages = [
  {
    role: "user",
    content: "Explain the difference between full binary tree and complete binary tree with examples."
  },
  {
    role: "assistant",
    content: `A **Full Binary Tree** is a tree in which every node has either 0 or 2 children. No node has only one child.

A **Complete Binary Tree** is a tree in which all levels are completely filled except possibly the last level, and the last level nodes are as far left as possible.

**Example of Full Binary Tree:**
\`\`\`
       1
      / \\
     2   3
    / \\
   4   5
\`\`\`

**Example of Complete Binary Tree:**
\`\`\`
       1
      / \\
     2   3
    / \\  /
   4   5 6
\`\`\`

**Key Differences:**
- In a full binary tree, internal nodes always have exactly 2 children
- In a complete binary tree, the last level is filled from left to right
- A complete binary tree is ideal for heap implementations`
  }
]

const sources = [
  { name: "Data Structures Notes.pdf", page: 42, confidence: 95 },
  { name: "Binary Trees Guide.pdf", page: 15, confidence: 88 },
]

export function StudyWorkspace({ subjectName, documentName, onBack, onGenerateQuiz }: StudyWorkspaceProps) {
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages] = useState(142)
  const [zoom, setZoom] = useState(100)
  const [inputMessage, setInputMessage] = useState("")

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputMessage.trim()) return
    setInputMessage("")
  }

  return (
    <div className="flex-1 flex h-screen overflow-hidden">
      {/* Left Pane - PDF Viewer (60%) */}
      <div className="w-[60%] flex flex-col border-r border-border">
        {/* PDF Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ChevronLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground truncate max-w-[200px]">
                {documentName}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => setZoom(Math.max(50, zoom - 10))}>
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm text-muted-foreground w-12 text-center">{zoom}%</span>
            <Button variant="ghost" size="icon" onClick={() => setZoom(Math.min(200, zoom + 10))}>
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <Maximize2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Upload Drop Zone */}
        <div className="px-4 py-2 bg-secondary/30 border-b border-border">
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Upload className="w-4 h-4" />
            <span>Drop PDF here to replace</span>
            <span className="text-yellow-500 font-medium">Max File Size: 50MB</span>
          </div>
        </div>

        {/* PDF Content Area */}
        <div className="flex-1 bg-secondary/20 overflow-auto p-8">
          <div 
            className="bg-white rounded-lg shadow-lg mx-auto p-8 text-gray-800"
            style={{ 
              width: `${Math.min(800, 600 * zoom / 100)}px`,
              minHeight: '800px'
            }}
          >
            <h1 className="text-2xl font-bold mb-4">4.1 Binary Trees</h1>
            <p className="mb-4 leading-relaxed">
              A binary tree is a tree data structure in which each node has at most two children, 
              referred to as the left child and the right child.
            </p>
            <h2 className="text-lg font-semibold mt-6 mb-3">Properties:</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>The maximum number of nodes at level l is 2^l</li>
              <li>Maximum number of nodes in a binary tree of height h is 2^(h+1) - 1</li>
              <li>In a Binary Tree with N nodes, minimum height is log2(N+1) - 1</li>
            </ul>
            
            {/* Tree Diagram */}
            <div className="my-8 flex justify-center">
              <svg width="300" height="200" viewBox="0 0 300 200">
                {/* Level 0 */}
                <circle cx="150" cy="30" r="20" fill="#8b5cf6" />
                <text x="150" y="35" textAnchor="middle" fill="white" fontSize="14">1</text>
                
                {/* Level 1 */}
                <line x1="135" y1="45" x2="85" y2="75" stroke="#8b5cf6" strokeWidth="2" />
                <line x1="165" y1="45" x2="215" y2="75" stroke="#8b5cf6" strokeWidth="2" />
                <circle cx="75" cy="90" r="20" fill="#8b5cf6" />
                <text x="75" y="95" textAnchor="middle" fill="white" fontSize="14">2</text>
                <circle cx="225" cy="90" r="20" fill="#8b5cf6" />
                <text x="225" y="95" textAnchor="middle" fill="white" fontSize="14">3</text>
                
                {/* Level 2 */}
                <line x1="60" y1="105" x2="35" y2="135" stroke="#8b5cf6" strokeWidth="2" />
                <line x1="90" y1="105" x2="115" y2="135" stroke="#8b5cf6" strokeWidth="2" />
                <line x1="210" y1="105" x2="185" y2="135" stroke="#8b5cf6" strokeWidth="2" />
                <line x1="240" y1="105" x2="265" y2="135" stroke="#8b5cf6" strokeWidth="2" />
                <circle cx="30" cy="150" r="20" fill="#22c55e" />
                <text x="30" y="155" textAnchor="middle" fill="white" fontSize="14">4</text>
                <circle cx="120" cy="150" r="20" fill="#22c55e" />
                <text x="120" y="155" textAnchor="middle" fill="white" fontSize="14">5</text>
                <circle cx="180" cy="150" r="20" fill="#22c55e" />
                <text x="180" y="155" textAnchor="middle" fill="white" fontSize="14">6</text>
                <circle cx="270" cy="150" r="20" fill="#22c55e" />
                <text x="270" y="155" textAnchor="middle" fill="white" fontSize="14">7</text>
              </svg>
            </div>

            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mt-6">
              <p className="text-sm text-purple-800">
                <strong>Note:</strong> Binary trees are widely used in computer science for efficient 
                data representation and searching algorithms.
              </p>
            </div>
          </div>
        </div>

        {/* PDF Footer - Page Navigation */}
        <div className="flex items-center justify-center gap-4 px-4 py-3 border-t border-border bg-card">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-sm text-foreground">
            Page {currentPage} of {totalPages}
          </span>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Right Pane - RAG AI Chat (40%) */}
      <div className="w-[40%] flex flex-col bg-card">
        {/* Chat Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">AI Study Assistant</h3>
              <p className="text-xs text-muted-foreground">Ask questions about {documentName}</p>
            </div>
          </div>
        </div>

        {/* Sources Panel */}
        <div className="px-4 py-3 border-b border-border bg-secondary/30">
          <div className="text-xs font-medium text-muted-foreground mb-2">Sources ({sources.length})</div>
          <div className="flex flex-wrap gap-2">
            {sources.map((source, idx) => (
              <div 
                key={idx}
                className="flex items-center gap-2 px-2 py-1 bg-card rounded border border-border text-xs"
              >
                <FileText className="w-3 h-3 text-primary" />
                <span className="text-foreground">{source.name}</span>
                <span className="text-muted-foreground">p.{source.page}</span>
                <span className="text-green-400">{source.confidence}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-auto p-4 space-y-4">
          {chatMessages.map((message, idx) => (
            <div key={idx} className={cn("flex gap-3", message.role === "user" ? "flex-row-reverse" : "")}>
              <div className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                message.role === "user" ? "bg-primary" : "bg-secondary"
              )}>
                {message.role === "user" ? (
                  <User className="w-4 h-4 text-primary-foreground" />
                ) : (
                  <Sparkles className="w-4 h-4 text-primary" />
                )}
              </div>
              <div className={cn(
                "max-w-[85%] rounded-xl px-4 py-3",
                message.role === "user" 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-secondary text-foreground"
              )}>
                <div className="text-sm whitespace-pre-wrap">{message.content}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Generate Quiz Button */}
        <div className="px-4 py-3 border-t border-border">
          <Button 
            onClick={onGenerateQuiz}
            className="w-full bg-primary hover:bg-primary/90 h-12 text-base font-semibold"
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Generate Adaptive Quiz
          </Button>
        </div>

        {/* Chat Input */}
        <form onSubmit={handleSendMessage} className="p-4 border-t border-border">
          <div className="flex gap-2">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask anything about your documents..."
              className="bg-secondary border-border"
            />
            <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
