"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts"
import { cn } from "@/lib/utils"
import { Progress } from "@/components/ui/progress"

const quizScoreData = [
  { date: "Apr 28", score: 45 },
  { date: "May 5", score: 60 },
  { date: "May 12", score: 55 },
  { date: "May 18", score: 70 },
  { date: "May 26", score: 85 },
]

const masteryData = [
  { name: "Strong", value: 14, color: "#22c55e" },
  { name: "Good", value: 3, color: "#eab308" },
  { name: "Weak", value: 7, color: "#ef4444" },
]

const heatmapData = [
  { topic: "Arrays", w1: 88, w2: 92, w3: 90, w4: 95 },
  { topic: "Stacks & Queues", w1: 72, w2: 80, w3: 85, w4: 88 },
  { topic: "Trees", w1: 45, w2: 52, w3: 58, w4: 62 },
  { topic: "Graphs", w1: 40, w2: 44, w3: 48, w4: 55 },
  { topic: "Sorting", w1: 70, w2: 75, w3: 82, w4: 90 },
  { topic: "Hashing", w1: 50, w2: 62, w3: 68, w4: 72 },
  { topic: "DP", w1: 30, w2: 38, w3: 41, w4: 45 },
  { topic: "Greedy", w1: 65, w2: 70, w3: 78, w4: 84 },
]

const weakTopics = [
  { topic: "Binary Trees", mastery: 32, lastPracticed: "3 days ago" },
  { topic: "Graph Traversal", mastery: 45, lastPracticed: "5 days ago" },
  { topic: "Dynamic Programming", mastery: 41, lastPracticed: "4 days ago" },
  { topic: "Heap Operations", mastery: 38, lastPracticed: "1 week ago" },
  { topic: "Recursion", mastery: 55, lastPracticed: "2 days ago" },
]

export function Analytics() {
  return (
    <div className="flex-1 p-6 space-y-6 overflow-auto">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Analytics & Knowledge Gaps</h1>
          <p className="text-muted-foreground">Track your learning progress and identify areas for improvement</p>
        </div>
        <div className="flex items-center gap-3">
          <select defaultValue="Overall Mastery" className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground w-fit">
            <option>Overall Mastery</option>
            <option>Data Structures</option>
            <option>Algorithms</option>
            <option>Operating Systems</option>
            <option>Database Systems</option>
          </select>
          <select defaultValue="Last 30 Days" className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground w-fit">
            <option>Last 7 Days</option>
            <option>Last 30 Days</option>
            <option>Last 90 Days</option>
          </select>
        </div>
      </div>

      {/* Knowledge Gap Summary - Radial Chart */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">Knowledge Gap Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="relative">
              <div className="w-48 h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={masteryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={85}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {masteryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold text-foreground">68%</span>
                <span className="text-sm text-muted-foreground">Overall Mastery</span>
              </div>
            </div>
            <div className="space-y-4 flex-1">
              {masteryData.map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-foreground font-medium">{item.name} Topics</span>
                  </div>
                  <span className="text-muted-foreground">{item.value} ({Math.round(item.value / 24 * 100)}%)</span>
                </div>
              ))}
              <div className="text-sm text-green-400 pt-2">+8% improvement from last 30 days</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quiz Score Trend - Line Graph */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">Quiz Score Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={quizScoreData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: '#71717a', fontSize: 12 }}
                  axisLine={{ stroke: '#27272a' }}
                />
                <YAxis 
                  tick={{ fill: '#71717a', fontSize: 12 }}
                  axisLine={{ stroke: '#27272a' }}
                  domain={[0, 100]}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e1e2e', 
                    border: '1px solid #27272a',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="score" 
                  stroke="#8b5cf6" 
                  strokeWidth={3}
                  dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 5 }}
                  activeDot={{ r: 7, fill: '#a78bfa' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Mastery Heatmap */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">Mastery Heatmap</CardTitle>
          <p className="text-sm text-muted-foreground">Weekly progress across topics</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="grid grid-cols-5 gap-2 text-sm text-muted-foreground mb-3">
              <div></div>
              <div className="text-center">Week 1</div>
              <div className="text-center">Week 2</div>
              <div className="text-center">Week 3</div>
              <div className="text-center">Week 4</div>
            </div>
            {heatmapData.map((row) => (
              <div key={row.topic} className="grid grid-cols-5 gap-2 items-center">
                <div className="text-sm text-foreground truncate">{row.topic}</div>
                {[row.w1, row.w2, row.w3, row.w4].map((val, i) => (
                  <div
                    key={i}
                    className={cn(
                      "h-8 rounded-md flex items-center justify-center text-xs font-medium",
                      val >= 80 && "bg-green-500 text-white",
                      val >= 60 && val < 80 && "bg-yellow-500 text-black",
                      val < 60 && "bg-red-500 text-white"
                    )}
                  >
                    {val}%
                  </div>
                ))}
              </div>
            ))}
          </div>
          
          {/* Legend - 3 tier with 60% failure threshold */}
          <div className="flex flex-wrap items-center justify-center gap-6 mt-6 pt-4 border-t border-border">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-green-500" />
              <span className="text-xs text-muted-foreground">Strong (80-100%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-yellow-500" />
              <span className="text-xs text-muted-foreground">Good (60-79%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-red-500" />
              <span className="text-xs text-muted-foreground">Weak / Gap (0-59%)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weak Topics Progress Bars */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">Top Weak Topics (Need Attention)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-5">
            {weakTopics.map((topic) => (
              <div key={topic.topic} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-foreground font-medium">{topic.topic}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground">{topic.lastPracticed}</span>
                    <span className={cn(
                      "text-sm font-semibold w-12 text-right",
                      topic.mastery < 40 ? "text-red-400" : "text-orange-400"
                    )}>
                      {topic.mastery}%
                    </span>
                    <Button size="sm" variant="outline" className="text-primary border-primary/30 hover:bg-primary/20 h-7 text-xs">
                      Review
                    </Button>
                  </div>
                </div>
                <div className="h-2.5 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all",
                      topic.mastery < 40 ? "bg-red-500" : "bg-orange-500"
                    )}
                    style={{ width: `${topic.mastery}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
