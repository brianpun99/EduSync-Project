"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, BookOpenCheck, ClipboardList } from "lucide-react"
import { cn } from "@/lib/utils"

const quizHistory = [
  { id: 1, date: "Jun 8, 2026", subject: "Data Structures", topic: "Binary Trees", score: 55 },
  { id: 2, date: "Jun 7, 2026", subject: "Algorithms", topic: "Sorting Algorithms", score: 78 },
  { id: 3, date: "Jun 6, 2026", subject: "Data Structures", topic: "Graph Traversal", score: 65 },
  { id: 4, date: "Jun 5, 2026", subject: "Algorithms", topic: "Dynamic Programming", score: 41 },
  { id: 5, date: "Jun 4, 2026", subject: "Operating Systems", topic: "Process Management", score: 82 },
  { id: 6, date: "Jun 2, 2026", subject: "Database Systems", topic: "Normalization", score: 90 },
  { id: 7, date: "May 30, 2026", subject: "Data Structures", topic: "Hash Tables", score: 52 },
  { id: 8, date: "May 28, 2026", subject: "Computer Networks", topic: "TCP/IP Protocol", score: 68 },
]

export function QuizHistory() {
  return (
    <div className="flex-1 p-6 space-y-6 overflow-auto">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Quizzes</h1>
          <p className="text-muted-foreground">Review your past quizzes and revisit AI explanations</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative max-w-xs w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search quizzes..." className="pl-10 bg-secondary border-border" />
          </div>
          <select defaultValue="Last 30 Days" className="bg-secondary border border-border rounded-lg px-3 py-2 text-sm text-foreground w-fit">
            <option>Last 7 Days</option>
            <option>Last 30 Days</option>
            <option>Last 90 Days</option>
            <option>All Time</option>
          </select>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryCard label="Total Quizzes" value="8" color="text-primary" />
        <SummaryCard label="Average Score" value="66%" color="text-cyan-400" />
        <SummaryCard label="Mastered" value="5" color="text-green-400" />
        <SummaryCard label="Knowledge Gaps" value="3" color="text-red-400" />
      </div>

      {/* History Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-primary" />
            Quiz History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-muted-foreground">
                  <th className="pb-3 font-medium">Date Taken</th>
                  <th className="pb-3 font-medium">Subject / Topic</th>
                  <th className="pb-3 font-medium">Score Achieved</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {quizHistory.map((quiz) => {
                  const isGap = quiz.score < 60
                  return (
                    <tr key={quiz.id} className="border-b border-border/50 last:border-0 hover:bg-secondary/30 transition-colors">
                      <td className="py-4 text-muted-foreground whitespace-nowrap">{quiz.date}</td>
                      <td className="py-4">
                        <div className="font-medium text-foreground">{quiz.topic}</div>
                        <div className="text-xs text-muted-foreground">{quiz.subject}</div>
                      </td>
                      <td className="py-4">
                        <span className={cn(
                          "font-semibold",
                          isGap ? "text-red-400" : quiz.score >= 80 ? "text-green-400" : "text-yellow-400"
                        )}>
                          {quiz.score}%
                        </span>
                      </td>
                      <td className="py-4">
                        <span className={cn(
                          "inline-flex px-3 py-1 rounded-full text-xs font-medium",
                          isGap 
                            ? "bg-red-500/20 text-red-400" 
                            : "bg-green-500/20 text-green-400"
                        )}>
                          {isGap ? "Knowledge Gap" : "Mastered"}
                        </span>
                      </td>
                      <td className="py-4 text-right">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-primary/40 text-primary hover:bg-primary/10 h-8 text-xs"
                        >
                          <BookOpenCheck className="w-3.5 h-3.5 mr-1.5" />
                          Review Answers
                        </Button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function SummaryCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="text-sm text-muted-foreground mb-1">{label}</div>
        <div className={cn("text-2xl lg:text-3xl font-bold", color)}>{value}</div>
      </CardContent>
    </Card>
  )
}
